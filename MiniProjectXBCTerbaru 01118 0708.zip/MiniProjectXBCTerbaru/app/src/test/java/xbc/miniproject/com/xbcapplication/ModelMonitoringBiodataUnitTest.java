package xbc.miniproject.com.xbcapplication;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * ModelBiodata local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ModelMonitoringBiodataUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}