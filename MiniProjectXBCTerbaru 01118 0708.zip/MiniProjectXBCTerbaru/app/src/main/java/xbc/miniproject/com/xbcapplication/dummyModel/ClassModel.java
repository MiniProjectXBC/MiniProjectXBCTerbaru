package xbc.miniproject.com.xbcapplication.dummyModel;

public class ClassModel {
    private String batch;
    private String name;

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

