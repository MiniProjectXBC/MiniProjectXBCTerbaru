package xbc.miniproject.com.xbcapplication.dummyModel;

public class TechnologyModel {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
