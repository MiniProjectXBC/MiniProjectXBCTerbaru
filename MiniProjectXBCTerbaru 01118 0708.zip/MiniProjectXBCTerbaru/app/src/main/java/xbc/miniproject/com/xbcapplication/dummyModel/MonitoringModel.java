package xbc.miniproject.com.xbcapplication.dummyModel;

public class MonitoringModel {
    private String name;
    private String idleDate;
    private String placementDate;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdleDate() {
        return idleDate;
    }

    public void setIdleDate(String idleDate) {
        this.idleDate = idleDate;
    }

    public String getPlacementDate() {
        return placementDate;
    }

    public void setPlacementDate(String placementDate) {
        this.placementDate = placementDate;
    }
}
